import Header from "@/components/header"
import Footer from "@/components/footer"
import Link from "next/link"

const allPhotos = [
  {
    id: 1,
    title: "Annual General Meeting 2025",
    category: "Annual General Meeting",
    image: "/congress-annual-meeting-gathering.jpg",
    date: "January 15, 2025",
    description:
      "The 2025 Annual General Meeting brought together members and leaders from across Malaysia to discuss strategic initiatives and organizational priorities.",
  },
  {
    id: 2,
    title: "Community Outreach Drive",
    category: "Community Service",
    image: "/community-service-volunteers-helping.jpg",
    date: "January 12, 2025",
    description:
      "Our community outreach team conducted a comprehensive welfare program reaching underprivileged communities with health services and educational materials.",
  },
  {
    id: 3,
    title: "Youth Leadership Workshop",
    category: "Youth Programs",
    image: "/young-people-learning-training.jpg",
    date: "January 10, 2025",
    description:
      "A transformative workshop designed to enhance leadership skills and political awareness among young members of the organization.",
  },
  {
    id: 4,
    title: "Women Leaders Conference",
    category: "Women Empowerment",
    image: "/women-empowerment-conference.jpg",
    date: "January 8, 2025",
    description:
      "Over 200 women leaders gathered to discuss gender equality, economic empowerment, and social justice initiatives.",
  },
  {
    id: 5,
    title: "Board Meeting Session",
    category: "Annual General Meeting",
    image: "/professional-leaders-meeting-discussion.jpg",
    date: "January 5, 2025",
    description:
      "Strategic planning session with the board of directors to finalize policies and action plans for the year.",
  },
  {
    id: 6,
    title: "Charity Fundraiser Gala",
    category: "Cultural Events",
    image: "/charity-event-fundraising.jpg",
    date: "December 28, 2024",
    description:
      "An elegant gala event that raised significant funds for our scholarship and community development programs.",
  },
  {
    id: 7,
    title: "Community Health Camp",
    category: "Community Service",
    image: "/congress-annual-meeting-gathering.jpg",
    date: "December 25, 2024",
    description:
      "Free health checkup and medical awareness camp serving over 500 community members with professional medical services.",
  },
  {
    id: 8,
    title: "Youth Morcha Sports Event",
    category: "Youth Programs",
    image: "/youth-morcha.jpg",
    date: "December 20, 2024",
    description:
      "A sports tournament organized by the Youth Morcha promoting physical fitness and healthy competition among young members.",
  },
  {
    id: 9,
    title: "Women's Skills Workshop",
    category: "Women Empowerment",
    image: "/womens-wing.jpg",
    date: "December 18, 2024",
    description:
      "Comprehensive skills development program covering digital literacy, entrepreneurship, and professional development for women.",
  },
  {
    id: 10,
    title: "Cultural Festival Celebration",
    category: "Cultural Events",
    image: "/community-service-volunteers-helping.jpg",
    date: "December 15, 2024",
    description:
      "Celebrating our rich cultural heritage with traditional performances, cuisines, and community participation.",
  },
  {
    id: 11,
    title: "Environmental Initiative",
    category: "Community Service",
    image: "/professional-leaders-meeting-discussion.jpg",
    date: "December 12, 2024",
    description:
      "Tree planting and environmental conservation drive involving hundreds of volunteers across multiple locations.",
  },
  {
    id: 12,
    title: "Youth Mentorship Program",
    category: "Youth Programs",
    image: "/young-people-learning-training.jpg",
    date: "December 10, 2024",
    description:
      "One-on-one mentoring sessions connecting experienced leaders with young members for personal and professional development.",
  },
]

export default function PhotoDetailPage({ params }: { params: { id: string } }) {
  const photo = allPhotos.find((p) => p.id === Number.parseInt(params.id))

  if (!photo) {
    return (
      <main className="flex flex-col w-full">
        <Header />
        <section className="py-20">
          <div className="max-w-4xl mx-auto px-4 text-center">
            <h1 className="text-3xl font-bold text-[#003087]">Photo Not Found</h1>
            <Link href="/media/photos" className="text-[#CE0000] font-bold mt-4 inline-block">
              Back to Gallery →
            </Link>
          </div>
        </section>
        <Footer />
      </main>
    )
  }

  const relatedPhotos = allPhotos.filter((p) => p.category === photo.category && p.id !== photo.id).slice(0, 3)

  return (
    <main className="flex flex-col w-full">
      <Header />

      <section className="bg-gradient-to-r from-[#003087] to-[#CE0000] text-white py-8 sm:py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Link href="/media/photos" className="text-white hover:opacity-80 transition-opacity mb-4 inline-block">
            ← Back to Photo Gallery
          </Link>
          <h1 className="text-3xl sm:text-4xl font-bold">{photo.title}</h1>
        </div>
      </section>

      <section className="py-12 sm:py-16 lg:py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-8">
            <img src={photo.image || "/placeholder.svg"} alt={photo.title} className="w-full rounded-lg shadow-lg" />
          </div>

          <div className="bg-white rounded-lg shadow-lg p-8 mb-12">
            <p className="text-sm text-[#CE0000] font-bold mb-2">{photo.category}</p>
            <p className="text-gray-600 mb-4">{photo.date}</p>
            <p className="text-lg text-gray-800 leading-relaxed">{photo.description}</p>
          </div>

          {relatedPhotos.length > 0 && (
            <div className="mt-12">
              <h2 className="text-2xl font-bold text-[#003087] mb-6">Related Photos</h2>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                {relatedPhotos.map((relatedPhoto) => (
                  <Link
                    key={relatedPhoto.id}
                    href={`/media/photos/${relatedPhoto.id}`}
                    className="group overflow-hidden rounded-lg shadow-lg hover:shadow-xl transition-shadow"
                  >
                    <div className="relative w-full h-48 bg-gray-200">
                      <img
                        src={relatedPhoto.image || "/placeholder.svg"}
                        alt={relatedPhoto.title}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                      />
                    </div>
                    <div className="p-4 bg-white">
                      <h3 className="font-bold text-[#003087]">{relatedPhoto.title}</h3>
                      <p className="text-xs text-gray-500 mt-1">{relatedPhoto.date}</p>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          )}
        </div>
      </section>

      <Footer />
    </main>
  )
}
