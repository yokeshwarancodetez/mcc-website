import Header from "@/components/header"
import Footer from "@/components/footer"
import Link from "next/link"

const allVideos = [
  {
    id: 1,
    title: "Annual General Meeting Address 2025",
    category: "Speeches",
    youtubeId: "dQw4w9WgXcQ",
    date: "January 15, 2025",
    duration: "12:34",
    description:
      "Watch our President's comprehensive address at the 2025 Annual General Meeting, covering key initiatives and organizational vision for the year ahead.",
  },
  {
    id: 2,
    title: "Community Service Impact Report",
    category: "News & Updates",
    youtubeId: "dQw4w9WgXcQ",
    date: "January 12, 2025",
    duration: "8:45",
    description:
      "A detailed report showcasing the impact of our community service programs and the lives touched by MCC's initiatives.",
  },
  {
    id: 3,
    title: "Youth Leadership Training Highlights",
    category: "Programs",
    youtubeId: "dQw4w9WgXcQ",
    date: "January 10, 2025",
    duration: "15:20",
    description:
      "Highlights from our intensive youth leadership training program designed to develop the next generation of community leaders.",
  },
  {
    id: 4,
    title: "Women Empowerment Conference Summary",
    category: "Events",
    youtubeId: "dQw4w9WgXcQ",
    date: "January 8, 2025",
    duration: "10:15",
    description:
      "Coverage of our annual Women Empowerment Conference where over 200 female leaders gathered to discuss gender equality and economic empowerment.",
  },
  {
    id: 5,
    title: "President's Speech on Social Justice",
    category: "Speeches",
    youtubeId: "dQw4w9WgXcQ",
    date: "January 5, 2025",
    duration: "18:50",
    description:
      "An inspiring speech addressing critical issues of social justice, equality, and the organization's commitment to building an inclusive society.",
  },
]

export default function VideoDetailPage({ params }: { params: { id: string } }) {
  const video = allVideos.find((v) => v.id === Number.parseInt(params.id))

  if (!video) {
    return (
      <main className="flex flex-col w-full">
        <Header />
        <section className="py-20">
          <div className="max-w-4xl mx-auto px-4 text-center">
            <h1 className="text-3xl font-bold text-[#003087]">Video Not Found</h1>
            <Link href="/media/videos" className="text-[#CE0000] font-bold mt-4 inline-block">
              Back to Video Gallery →
            </Link>
          </div>
        </section>
        <Footer />
      </main>
    )
  }

  return (
    <main className="flex flex-col w-full">
      <Header />

      <section className="bg-gradient-to-r from-[#CE0000] to-[#003087] text-white py-8 sm:py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Link href="/media/videos" className="text-white hover:opacity-80 transition-opacity mb-4 inline-block">
            ← Back to Video Gallery
          </Link>
          <h1 className="text-3xl sm:text-4xl font-bold">{video.title}</h1>
        </div>
      </section>

      <section className="py-12 sm:py-16 lg:py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-8 aspect-video bg-black rounded-lg overflow-hidden shadow-lg">
            <iframe
              width="100%"
              height="100%"
              src={`https://www.youtube.com/embed/${video.youtubeId}`}
              title={video.title}
              frameBorder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
              className="w-full h-full"
            ></iframe>
          </div>

          <div className="bg-white rounded-lg shadow-lg p-8 mb-12">
            <p className="text-sm text-[#CE0000] font-bold mb-2">{video.category}</p>
            <p className="text-gray-600 mb-2">{video.date}</p>
            <p className="text-sm text-gray-500 mb-4">Duration: {video.duration}</p>
            <p className="text-lg text-gray-800 leading-relaxed">{video.description}</p>
          </div>

          {/* Share section */}
          <div className="bg-gray-50 rounded-lg p-6 border border-gray-200">
            <h3 className="font-bold text-[#003087] mb-4">Share This Video</h3>
            <div className="flex gap-3">
              <button className="px-4 py-2 bg-[#003087] text-white rounded hover:bg-[#002060] transition-colors text-sm font-semibold">
                Facebook
              </button>
              <button className="px-4 py-2 bg-[#003087] text-white rounded hover:bg-[#002060] transition-colors text-sm font-semibold">
                Twitter
              </button>
              <button className="px-4 py-2 bg-[#CE0000] text-white rounded hover:bg-[#B00000] transition-colors text-sm font-semibold">
                Copy Link
              </button>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}
