"use client"
import Header from "@/components/header"
import Footer from "@/components/footer"
import Link from "next/link"
import { useParams } from "next/navigation"

const categoryDetails = {
  "corporate-leaders": {
    title: "Corporate Leaders",
    image: "/corporate-leaders.jpg",
    description: "Join our network of accomplished corporate professionals and business leaders",
    overview:
      "The Corporate Leaders sector brings together senior executives, C-suite professionals, and business entrepreneurs who are committed to driving economic development and organizational excellence within the Malaysian Ceylonese community.",
    keyAreas: [
      "Business Strategy & Management",
      "Executive Leadership Development",
      "Corporate Social Responsibility",
      "International Trade & Commerce",
      "Investment & Finance",
      "Human Resource Management",
    ],
    opportunities: [
      "Networking with industry leaders",
      "Business collaboration opportunities",
      "Executive mentorship programs",
      "Corporate partnership initiatives",
      "Industry seminars and workshops",
      "Market expansion support",
    ],
    members: "500+",
    impact: "Generated RM 50 Million in business partnerships",
  },
  "technology-innovation": {
    title: "Technology & Innovation",
    image: "/technology-innovation.jpg",
    description: "Pioneer digital transformation and technological advancement",
    overview:
      "Our Technology & Innovation wing comprises software engineers, entrepreneurs, researchers, and tech enthusiasts dedicated to leveraging cutting-edge technology for community development and digital innovation.",
    keyAreas: [
      "Software Development",
      "Artificial Intelligence & Machine Learning",
      "Digital Transformation",
      "Startup Ecosystem",
      "Cybersecurity",
      "Cloud Computing",
    ],
    opportunities: [
      "Tech incubation programs",
      "Innovation hackathons",
      "Startup funding support",
      "Technology partnerships",
      "Skill development workshops",
      "Patent and IP support",
    ],
    members: "350+",
    impact: "20+ successful tech startups launched",
  },
  "healthcare-professionals": {
    title: "Healthcare Professionals",
    image: "/healthcare-professionals.jpg",
    description: "Advancing healthcare excellence and community wellness",
    overview:
      "Healthcare professionals including doctors, nurses, dentists, pharmacists, and healthcare administrators collaborate to improve healthcare delivery and promote wellness initiatives across communities.",
    keyAreas: [
      "Medical Practice & Research",
      "Public Health",
      "Telemedicine Solutions",
      "Healthcare Innovation",
      "Community Health Programs",
      "Professional Development",
    ],
    opportunities: [
      "Medical seminars and conferences",
      "Healthcare community outreach",
      "Professional certification support",
      "Research collaboration",
      "Telemedicine platform partnership",
      "Health advocacy initiatives",
    ],
    members: "400+",
    impact: "1000+ free health screening camps conducted",
  },
  "legal-experts": {
    title: "Legal Experts",
    image: "/legal-experts.jpg",
    description: "Upholding justice and legal excellence",
    overview:
      "Our Legal Experts network comprises practicing lawyers, judges, legal scholars, and law professionals committed to promoting justice, rule of law, and legal awareness within the community.",
    keyAreas: [
      "Corporate Law",
      "Constitutional Law",
      "Intellectual Property Rights",
      "Alternative Dispute Resolution",
      "Legal Advocacy",
      "Legal Education",
    ],
    opportunities: [
      "Legal consultation services",
      "Law seminars and workshops",
      "Legal literacy programs",
      "Pro bono services",
      "Law student mentorship",
      "Legal policy advocacy",
    ],
    members: "250+",
    impact: "5000+ legal consultations provided",
  },
  entrepreneurs: {
    title: "Entrepreneurs",
    image: "/entrepreneurs.jpg",
    description: "Building thriving businesses and economic growth",
    overview:
      "Entrepreneurs and business owners in our network create jobs, drive innovation, and contribute significantly to economic development while maintaining strong ties to community values.",
    keyAreas: [
      "Small & Medium Enterprises",
      "Business Development",
      "Export-Import Trade",
      "Retail & E-commerce",
      "Hospitality & Tourism",
      "Manufacturing & Services",
    ],
    opportunities: [
      "Business mentorship programs",
      "Funding and grants support",
      "Market access networks",
      "Business incubation programs",
      "Trade fair participation",
      "Supply chain partnerships",
    ],
    members: "600+",
    impact: "300+ new businesses established",
  },
  academics: {
    title: "Academics",
    image: "/academics.jpg",
    description: "Advancing knowledge and educational excellence",
    overview:
      "Academics including professors, researchers, educators, and academic administrators work to advance knowledge, improve educational systems, and develop future leaders through excellence in education.",
    keyAreas: [
      "Higher Education",
      "Research & Development",
      "Curriculum Development",
      "Student Mentorship",
      "Academic Publishing",
      "Educational Technology",
    ],
    opportunities: [
      "Research collaboration",
      "Academic conferences",
      "Teaching excellence programs",
      "Student scholarship support",
      "Academic publication support",
      "Educational innovation projects",
    ],
    members: "280+",
    impact: "500+ students mentored annually",
  },
}

export default function CategoryDetailPage() {
  const params = useParams()
  const categorySlug = params.category as string
  const category = categoryDetails[categorySlug as keyof typeof categoryDetails]

  if (!category) {
    return (
      <main className="flex flex-col w-full min-h-screen">
        <Header />
        <section className="py-20 text-center">
          <p className="text-gray-600">Category not found</p>
        </section>
        <Footer />
      </main>
    )
  }

  return (
    <main className="flex flex-col w-full">
      <Header />

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-[#003087] to-[#CE0000] text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Link href="/morcha/professional" className="text-red-200 hover:text-white mb-4 inline-block">
            ← Back to Professional Wing
          </Link>
          <h1 className="text-4xl sm:text-5xl font-bold mb-4">{category.title}</h1>
          <p className="text-xl text-gray-100">{category.description}</p>
        </div>
      </section>

      {/* Overview Section */}
      <section className="py-12 sm:py-16 lg:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
            <div>
              <h2 className="text-3xl font-bold text-[#003087] mb-6">About This Wing</h2>
              <p className="text-gray-700 leading-relaxed mb-6">{category.overview}</p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="bg-blue-50 p-4 rounded-lg">
                  <p className="text-sm text-gray-600">Active Members</p>
                  <p className="text-2xl font-bold text-[#003087]">{category.members}</p>
                </div>
                <div className="bg-red-50 p-4 rounded-lg">
                  <p className="text-sm text-gray-600">Community Impact</p>
                  <p className="text-lg font-bold text-[#CE0000]">{category.impact}</p>
                </div>
              </div>
            </div>
            <div>
              <img
                src={category.image || "/placeholder.svg"}
                alt={category.title}
                className="w-full rounded-lg shadow-lg object-cover h-96"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Key Areas Section */}
      <section className="py-12 sm:py-16 lg:py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-[#003087] mb-10 text-center">Key Focus Areas</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {category.keyAreas.map((area, index) => (
              <div key={index} className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
                <div className="flex items-start">
                  <div className="w-3 h-3 bg-[#CE0000] rounded-full mt-2 mr-4 flex-shrink-0"></div>
                  <p className="text-gray-800 font-semibold">{area}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Opportunities Section */}
      <section className="py-12 sm:py-16 lg:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-[#003087] mb-10 text-center">Membership Opportunities</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {category.opportunities.map((opportunity, index) => (
              <div key={index} className="flex items-start bg-blue-50 p-6 rounded-lg">
                <div className="w-5 h-5 bg-[#CE0000] rounded-full mt-1 mr-4 flex-shrink-0"></div>
                <p className="text-gray-800">{opportunity}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-[#003087] to-[#CE0000] text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Join {category.title}?</h2>
          <p className="text-lg mb-8 text-gray-100">Become part of our professional network and make an impact</p>
          <Link
            href="/membership"
            className="inline-block bg-white text-[#003087] font-bold py-3 px-8 rounded-lg hover:bg-gray-100 transition-colors"
          >
            Become a Member
          </Link>
        </div>
      </section>

      <Footer />
    </main>
  )
}
