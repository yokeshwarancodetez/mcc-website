"use client"

import type React from "react"

import { useState } from "react"
import Header from "@/components/header"
import Footer from "@/components/footer"
import { Check } from "lucide-react"

interface FormData {
  // Personal Particulars
  fullName: string
  dateOfBirth: string
  gender: string
  icNumber: string
  icFile: File | null
  mobileNumber: string
  email: string
  homeAddress: string

  // Political Affiliation
  currentPoliticalParty: string
  politicalPartyName: string

  // Branch Selection
  selectedBranch: string

  // Membership Details
  membershipType: string

  // Consent
  pdpaConsent: boolean
  constitutionConsent: boolean
}

const BRANCHES = [
  "Kuala Lumpur",
  "Selangor",
  "Johor",
  "Penang",
  "Perak",
  "Pahang",
  "Terengganu",
  "Kelantan",
  "Kedah",
  "Perlis",
  "Negeri Sembilan",
  "Malacca",
  "Sabah",
  "Sarawak",
]

export default function MembershipPage() {
  const [formData, setFormData] = useState<FormData>({
    fullName: "",
    dateOfBirth: "",
    gender: "",
    icNumber: "",
    icFile: null,
    mobileNumber: "",
    email: "",
    homeAddress: "",
    currentPoliticalParty: "",
    politicalPartyName: "",
    selectedBranch: "",
    membershipType: "",
    pdpaConsent: false,
    constitutionConsent: false,
  })

  const [errors, setErrors] = useState<Record<string, string>>({})
  const [submitted, setSubmitted] = useState(false)

  const calculateMembershipFee = () => {
    if (formData.membershipType === "associate") {
      return "RM 50 (5 Years)"
    } else if (formData.membershipType === "ordinary") {
      return "RM 10 per year"
    }
    return "N/A"
  }

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {}

    if (!formData.fullName.trim()) newErrors.fullName = "Full name is required"
    if (!formData.dateOfBirth) newErrors.dateOfBirth = "Date of birth is required"
    if (!formData.gender) newErrors.gender = "Gender is required"
    if (!formData.icNumber.trim()) newErrors.icNumber = "IC number is required"
    if (!formData.icFile) newErrors.icFile = "IC/MyKad copy is required"
    if (!formData.mobileNumber.trim()) newErrors.mobileNumber = "Mobile number is required"
    if (!formData.homeAddress.trim()) newErrors.homeAddress = "Home address is required"
    if (!formData.selectedBranch) newErrors.selectedBranch = "Branch selection is required"
    if (!formData.membershipType) newErrors.membershipType = "Membership type is required"
    if (!formData.pdpaConsent) newErrors.pdpaConsent = "PDPA consent is required"
    if (!formData.constitutionConsent) newErrors.constitutionConsent = "Constitution consent is required"

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (validateForm()) {
      setSubmitted(true)
      console.log("Form submitted:", formData)
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target
    if (type === "checkbox") {
      const checked = (e.target as HTMLInputElement).checked
      setFormData((prev) => ({ ...prev, [name]: checked }))
    } else {
      setFormData((prev) => ({ ...prev, [name]: value }))
    }
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setFormData((prev) => ({ ...prev, icFile: file }))
    }
  }

  if (submitted) {
    return (
      <>
        <Header />
        <div className="min-h-screen bg-gradient-to-br from-blue-50 to-red-50 py-12">
          <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="bg-white rounded-xl shadow-2xl p-8 sm:p-12 text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-blue-900 to-red-700 rounded-full flex items-center justify-center mx-auto mb-6">
                <Check className="text-white" size={40} />
              </div>
              <h1 className="text-3xl sm:text-4xl font-black text-gray-900 mb-4">Application Submitted!</h1>
              <p className="text-lg text-gray-600 mb-8">
                Thank you for your membership application. We will review your information and contact you within 3-5
                business days.
              </p>
              <div className="bg-blue-50 border-l-4 border-blue-900 p-4 mb-8 text-left">
                <p className="text-sm text-gray-700">
                  <strong>Application Reference:</strong> MCC-{Date.now()}
                </p>
              </div>
              <a
                href="/"
                className="inline-block px-8 py-3 bg-gradient-to-r from-blue-900 to-red-700 text-white font-bold rounded-lg hover:shadow-lg transition-all"
              >
                Return to Home
              </a>
            </div>
          </div>
        </div>
        <Footer />
      </>
    )
  }

  return (
    <>
      <Header />
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-red-50 py-12">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="mb-12 text-center">
            <h1 className="text-4xl sm:text-5xl font-black text-gray-900 mb-4">MCC Membership Registration</h1>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Join the Malaysian Ceylonese Congress and become part of our vibrant community. Complete the form below to
              register your membership.
            </p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="bg-white rounded-xl shadow-2xl p-8 sm:p-12 space-y-8">
            {/* A. Personal Particulars */}
            <section className="space-y-6">
              <div className="border-b-2 border-blue-900 pb-4">
                <h2 className="text-2xl font-black text-blue-900">A. Personal Particulars</h2>
              </div>

              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">
                  Full Name<span className="text-red-700">*</span>
                </label>
                <input
                  type="text"
                  name="fullName"
                  value={formData.fullName}
                  onChange={handleInputChange}
                  className={`w-full px-4 py-3 border-2 rounded-lg focus:outline-none focus:border-blue-900 transition-colors ${
                    errors.fullName ? "border-red-500" : "border-gray-300"
                  }`}
                  placeholder="Enter your full name"
                />
                {errors.fullName && <p className="text-red-600 text-sm mt-1">{errors.fullName}</p>}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">
                    Date of Birth<span className="text-red-700">*</span>
                  </label>
                  <input
                    type="date"
                    name="dateOfBirth"
                    value={formData.dateOfBirth}
                    onChange={handleInputChange}
                    className={`w-full px-4 py-3 border-2 rounded-lg focus:outline-none focus:border-blue-900 transition-colors ${
                      errors.dateOfBirth ? "border-red-500" : "border-gray-300"
                    }`}
                  />
                  {errors.dateOfBirth && <p className="text-red-600 text-sm mt-1">{errors.dateOfBirth}</p>}
                </div>

                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">
                    Gender<span className="text-red-700">*</span>
                  </label>
                  <select
                    name="gender"
                    value={formData.gender}
                    onChange={handleInputChange}
                    className={`w-full px-4 py-3 border-2 rounded-lg focus:outline-none focus:border-blue-900 transition-colors ${
                      errors.gender ? "border-red-500" : "border-gray-300"
                    }`}
                  >
                    <option value="">Select Gender</option>
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                    <option value="others">Others</option>
                  </select>
                  {errors.gender && <p className="text-red-600 text-sm mt-1">{errors.gender}</p>}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">
                    IC Number (MyKad)<span className="text-red-700">*</span>
                  </label>
                  <input
                    type="text"
                    name="icNumber"
                    value={formData.icNumber}
                    onChange={handleInputChange}
                    className={`w-full px-4 py-3 border-2 rounded-lg focus:outline-none focus:border-blue-900 transition-colors ${
                      errors.icNumber ? "border-red-500" : "border-gray-300"
                    }`}
                    placeholder="XXXXXX-XX-XXXX"
                  />
                  {errors.icNumber && <p className="text-red-600 text-sm mt-1">{errors.icNumber}</p>}
                </div>

                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">
                    IC/MyKad Copy<span className="text-red-700">*</span>
                  </label>
                  <input
                    type="file"
                    accept=".jpg,.jpeg,.png,.pdf"
                    onChange={handleFileChange}
                    className={`w-full px-4 py-3 border-2 rounded-lg focus:outline-none focus:border-blue-900 transition-colors ${
                      errors.icFile ? "border-red-500" : "border-gray-300"
                    }`}
                  />
                  <p className="text-xs text-gray-500 mt-1">JPG, PNG, PDF (Max 5MB)</p>
                  {errors.icFile && <p className="text-red-600 text-sm mt-1">{errors.icFile}</p>}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">
                    Mobile Number<span className="text-red-700">*</span>
                  </label>
                  <input
                    type="tel"
                    name="mobileNumber"
                    value={formData.mobileNumber}
                    onChange={handleInputChange}
                    className={`w-full px-4 py-3 border-2 rounded-lg focus:outline-none focus:border-blue-900 transition-colors ${
                      errors.mobileNumber ? "border-red-500" : "border-gray-300"
                    }`}
                    placeholder="012-3456789"
                  />
                  {errors.mobileNumber && <p className="text-red-600 text-sm mt-1">{errors.mobileNumber}</p>}
                </div>

                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">Email Address (Optional)</label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:outline-none focus:border-blue-900 transition-colors"
                    placeholder="your.email@example.com"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">
                  Home Permanent Address<span className="text-red-700">*</span>
                </label>
                <textarea
                  name="homeAddress"
                  value={formData.homeAddress}
                  onChange={handleInputChange}
                  rows={3}
                  className={`w-full px-4 py-3 border-2 rounded-lg focus:outline-none focus:border-blue-900 transition-colors ${
                    errors.homeAddress ? "border-red-500" : "border-gray-300"
                  }`}
                  placeholder="Enter your complete home address"
                />
                {errors.homeAddress && <p className="text-red-600 text-sm mt-1">{errors.homeAddress}</p>}
              </div>
            </section>

            {/* B. Political Affiliation */}
            <section className="space-y-6">
              <div className="border-b-2 border-red-700 pb-4">
                <h2 className="text-2xl font-black text-red-700">B. Political Affiliation</h2>
              </div>

              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">
                  Are you currently a member of any political party?<span className="text-red-700">*</span>
                </label>
                <div className="flex gap-6">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      name="currentPoliticalParty"
                      value="yes"
                      checked={formData.currentPoliticalParty === "yes"}
                      onChange={handleInputChange}
                      className="w-4 h-4"
                    />
                    <span className="font-medium text-gray-700">Yes</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      name="currentPoliticalParty"
                      value="no"
                      checked={formData.currentPoliticalParty === "no"}
                      onChange={handleInputChange}
                      className="w-4 h-4"
                    />
                    <span className="font-medium text-gray-700">No</span>
                  </label>
                </div>
              </div>

              {formData.currentPoliticalParty === "yes" && (
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">Political Party Name</label>
                  <input
                    type="text"
                    name="politicalPartyName"
                    value={formData.politicalPartyName}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:outline-none focus:border-blue-900 transition-colors"
                    placeholder="Enter the name of the political party"
                  />
                </div>
              )}
            </section>

            {/* C. Branch Selection */}
            <section className="space-y-6">
              <div className="border-b-2 border-blue-900 pb-4">
                <h2 className="text-2xl font-black text-blue-900">C. Branch Selection</h2>
              </div>

              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">
                  Select Branch<span className="text-red-700">*</span>
                </label>
                <select
                  name="selectedBranch"
                  value={formData.selectedBranch}
                  onChange={handleInputChange}
                  className={`w-full px-4 py-3 border-2 rounded-lg focus:outline-none focus:border-blue-900 transition-colors ${
                    errors.selectedBranch ? "border-red-500" : "border-gray-300"
                  }`}
                >
                  <option value="">-- Please select the branch you wish to join --</option>
                  {BRANCHES.map((branch) => (
                    <option key={branch} value={branch}>
                      {branch}
                    </option>
                  ))}
                </select>
                {errors.selectedBranch && <p className="text-red-600 text-sm mt-1">{errors.selectedBranch}</p>}
              </div>
            </section>

            {/* D. Membership Details */}
            <section className="space-y-6">
              <div className="border-b-2 border-red-700 pb-4">
                <h2 className="text-2xl font-black text-red-700">D. Membership Details</h2>
              </div>

              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">
                  Membership Type<span className="text-red-700">*</span>
                </label>
                <select
                  name="membershipType"
                  value={formData.membershipType}
                  onChange={handleInputChange}
                  className={`w-full px-4 py-3 border-2 rounded-lg focus:outline-none focus:border-blue-900 transition-colors ${
                    errors.membershipType ? "border-red-500" : "border-gray-300"
                  }`}
                >
                  <option value="">-- Select Membership Type --</option>
                  <option value="associate">Associate Member (RM 50 for 5 Years)</option>
                  <option value="ordinary">Ordinary Member (RM 10 per year)</option>
                </select>
                {errors.membershipType && <p className="text-red-600 text-sm mt-1">{errors.membershipType}</p>}
              </div>

              {formData.membershipType && (
                <div className="bg-blue-50 border-l-4 border-blue-900 p-4">
                  <p className="text-sm font-bold text-gray-700">
                    Membership Fee: <span className="text-blue-900">{calculateMembershipFee()}</span>
                  </p>
                </div>
              )}
            </section>

            {/* E. Declaration & Consent */}
            <section className="space-y-6">
              <div className="border-b-2 border-blue-900 pb-4">
                <h2 className="text-2xl font-black text-blue-900">E. Declaration & Consent</h2>
              </div>

              <div className="bg-gray-50 p-6 rounded-lg border-2 border-gray-200">
                <h3 className="font-bold text-gray-900 mb-4">PDPA Consent Declaration</h3>
                <p className="text-sm text-gray-700 leading-relaxed mb-4">
                  I understand that Malaysian Ceylonese Congress will collect and process my personal data in accordance
                  with the Personal Data Protection Act 2010 (PDPA). My personal information will be used for membership
                  administration, communication, and organizational activities.
                </p>
                <label className="flex items-start gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    name="pdpaConsent"
                    checked={formData.pdpaConsent}
                    onChange={handleInputChange}
                    className="w-4 h-4 mt-1 cursor-pointer"
                  />
                  <span className="text-sm font-bold text-gray-700">
                    <span className="text-red-700">*</span> I consent to the collection and processing of my personal
                    data as described above.
                  </span>
                </label>
                {errors.pdpaConsent && <p className="text-red-600 text-sm mt-2">{errors.pdpaConsent}</p>}
              </div>

              <div className="bg-gray-50 p-6 rounded-lg border-2 border-gray-200">
                <h3 className="font-bold text-gray-900 mb-4">Constitution & Rules Declaration</h3>
                <p className="text-sm text-gray-700 leading-relaxed mb-4">
                  By becoming a member of the Malaysian Ceylonese Congress, I agree to abide by the Constitution and
                  rules of the organization.
                </p>
                <label className="flex items-start gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    name="constitutionConsent"
                    checked={formData.constitutionConsent}
                    onChange={handleInputChange}
                    className="w-4 h-4 mt-1 cursor-pointer"
                  />
                  <span className="text-sm font-bold text-gray-700">
                    <span className="text-red-700">*</span> I agree to abide by the Constitution and rules of the
                    Malaysian Ceylonese Congress.
                  </span>
                </label>
                {errors.constitutionConsent && (
                  <p className="text-red-600 text-sm mt-2">{errors.constitutionConsent}</p>
                )}
              </div>
            </section>

            {/* Submit Button */}
            <div className="flex gap-4 pt-8">
              <button
                type="submit"
                className="flex-1 px-8 py-4 bg-gradient-to-r from-blue-900 to-red-700 text-white font-black rounded-lg hover:shadow-xl transition-all uppercase tracking-wide"
              >
                Submit Application
              </button>
              <a
                href="/"
                className="flex-1 px-8 py-4 bg-gray-300 text-gray-900 font-black rounded-lg hover:bg-gray-400 transition-all uppercase tracking-wide text-center"
              >
                Cancel
              </a>
            </div>
          </form>
        </div>
      </div>
      <Footer />
    </>
  )
}
