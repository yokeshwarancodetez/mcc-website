"use client"

import { useState } from "react"
import Image from "next/image"
import { ChevronLeft, ChevronRight } from "lucide-react"

export default function FoundersHistory() {
  const [currentIndex, setCurrentIndex] = useState(0)

  const leaders = [
    {
      id: 1,
      name: "M.W. Navaratnam",
      title: "Founder & 1st President",
      period: "1958 - 1969",
      tenure: "11 years",
      image: "/leader-navaratnam.jpg",
      description:
        "Founded MCC with vision to support the Malaysian Ceylonese community. Established core organizational structure and principles.",
    },
    {
      id: 2,
      name: "Tan Sri Dr C. Sinnadurai",
      title: "2nd President",
      period: "1970 - 1983",
      tenure: "13 years",
      image: "/leader-sinnadurai.jpg",
      description:
        "Expanded MCC's reach and established community programs. Strengthened political engagement and cultural preservation.",
    },
    {
      id: 3,
      name: "Tan Sri Datin Seri V. Jeyaratnam",
      title: "3rd President",
      period: "1983 - 1987",
      tenure: "4 years",
      image: "/leader-jeyaratnam.jpg",
      description:
        "Enhanced educational and social welfare initiatives. Promoted youth development and community empowerment programs.",
    },
    {
      id: 4,
      name: "Dato Dr N. Arumugasamy",
      title: "4th President",
      period: "1988 - 1995",
      tenure: "7 years",
      image: "/leader-arumugasamy.jpg",
      description:
        "Pioneered healthcare and professional services. Advanced MCC's role as a political and cultural institution.",
    },
    {
      id: 5,
      name: "Datuk Dr D M Thuraiapah",
      title: "5th President",
      period: "1996 - 2003",
      tenure: "7 years",
      image: "/leader-thuraiapah.jpg",
      description:
        "Modernized MCC operations and expanded international relations. Strengthened community bonds and economic initiatives.",
    },
    {
      id: 6,
      name: "Dato' Dr N K S Tharmaseelan",
      title: "6th President",
      period: "2004 - 2023",
      tenure: "19 years",
      image: "/leader-tharmaseelan.jpg",
      description:
        "Led MCC through major transformation and digital advancement. Expanded membership, programs, and national influence.",
    },
    {
      id: 7,
      name: "Anwar bin Ibrahim",
      title: "Current President",
      period: "2024 - Present",
      tenure: "Current",
      image: "/anwar-bin-ibrahim-president.jpg",
      description:
        "Current president leading MCC into a new era of progress and inclusive community development with focus on innovation and digital transformation.",
    },
  ]

  const goToNext = () => {
    setCurrentIndex((prev) => (prev + 1) % leaders.length)
  }

  const goToPrev = () => {
    setCurrentIndex((prev) => (prev - 1 + leaders.length) % leaders.length)
  }

  const goToIndex = (index) => {
    setCurrentIndex(index)
  }

  const leader = leaders[currentIndex]

  return (
    <section className="w-full py-16 bg-white">
      <div className="max-w-6xl mx-auto px-4">
        {/* Section Title */}
        <div className="mb-12 text-center">
          <h2 className="text-4xl font-medium text-[#003087] mb-2">Founders & Presidents of MCC</h2>
          <p className="text-gray-600">Leadership journey through seven decades</p>
        </div>

        {/* Main Content - Two Column Layout */}
        <div className="grid md:grid-cols-2 gap-8 items-center mb-8">
          {/* Left - Image */}
          <div className="flex justify-center">
            <div className="relative w-full max-w-sm">
              <Image
                src={leader.image || "/placeholder.svg"}
                alt={leader.name}
                width={400}
                height={500}
                className="rounded-lg shadow-lg object-cover w-full h-auto"
              />
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black to-transparent p-4 rounded-lg">
                <p className="text-white font-semibold text-lg">{leader.name}</p>
                <p className="text-yellow-400 text-sm">{leader.period}</p>
              </div>
            </div>
          </div>

          {/* Right - Content */}
          <div className="space-y-6">
            <div>
              <h3 className="text-2xl font-semibold text-[#CE0000] mb-2">{leader.name}</h3>
              <p className="text-lg text-[#003087] font-medium mb-2">{leader.title}</p>
              <p className="text-gray-600 mb-4">
                {leader.period} • {leader.tenure}
              </p>
            </div>

            <div className="bg-blue-50 p-4 rounded-lg border-l-4 border-[#003087]">
              <p className="text-gray-700 leading-relaxed">{leader.description}</p>
            </div>

            {/* Navigation Buttons */}
            <div className="flex gap-4 pt-4">
              <button
                onClick={goToPrev}
                className="flex items-center gap-2 px-6 py-2 bg-[#003087] text-white rounded-lg hover:bg-[#002060] transition"
              >
                <ChevronLeft size={20} />
                Previous
              </button>
              <button
                onClick={goToNext}
                className="flex items-center gap-2 px-6 py-2 bg-[#CE0000] text-white rounded-lg hover:bg-[#9d0000] transition"
              >
                Next
                <ChevronRight size={20} />
              </button>
            </div>
          </div>
        </div>

        {/* Progress Indicator */}
        <div className="flex justify-center items-center gap-2 mt-8">
          <span className="text-sm text-gray-600">
            {currentIndex + 1} of {leaders.length}
          </span>
          <div className="flex gap-2">
            {leaders.map((_, index) => (
              <button
                key={index}
                onClick={() => goToIndex(index)}
                className={`w-3 h-3 rounded-full transition ${index === currentIndex ? "bg-[#003087]" : "bg-gray-300"}`}
                aria-label={`Go to leader ${index + 1}`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
