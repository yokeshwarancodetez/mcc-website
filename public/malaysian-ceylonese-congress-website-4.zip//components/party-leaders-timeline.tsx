"use client"

import { useState } from "react"
import { ChevronLeft, ChevronRight } from "lucide-react"
import Image from "next/image"

const partyLeaders = [
  {
    id: 1,
    name: "Mr. M.W. Navaratnam",
    title: "Founder & First President",
    years: "1958 - 1969",
    duration: "11 years",
    description:
      "Mr. M.W. Navaratnam, the visionary founder of MCC, established the Malaysian Ceylonese Congress in 1958 as a political party to give support to the then Alliance party. He pioneered the organization's mission to promote and preserve the political, educational, economical, social and cultural aspects of Malaysians of Ceylonese origin. His leadership laid the strong foundation for over six decades of community service.",
    image: "/leader-navaratnam.jpg",
  },
  {
    id: 2,
    name: "Senator Tan Sri Dr. C. Sinnadurai",
    title: "Second President",
    years: "1970 - 1983",
    duration: "13 years",
    description:
      "Senator Tan Sri Dr. C. Sinnadurai continued MCC's legacy during a critical period of growth. Under his leadership, the organization expanded its community programs and strengthened its political representation. His tenure saw significant advancement in education initiatives and cultural preservation efforts for the Malaysian Ceylonese community.",
    image: "/leader-sinnadurai.jpg",
  },
  {
    id: 3,
    name: "Tan Sri Dato' Seri V. Jeyaratnam",
    title: "Third President",
    years: "1983 - 1987",
    duration: "4 years",
    description:
      "Tan Sri Dato' Seri V. Jeyaratnam brought dynamic leadership to MCC during the 1980s. His focus on strengthening community ties and enhancing economic opportunities for MCC members resulted in significant organizational developments. He played a crucial role in maintaining MCC's unwavering commitment to Malaysia's national principles and constitutional framework.",
    image: "/leader-jeyaratnam.jpg",
  },
  {
    id: 4,
    name: "Dato Dr N. Arumugasamy",
    title: "Fourth President",
    years: "1988 - 1995",
    duration: "7 years",
    description:
      "Dato Dr N. Arumugasamy, a distinguished neurosurgeon, brought professional excellence and social commitment to MCC's leadership. His tenure emphasized the importance of health, education, professional development, and social equity among MCC members. Under his stewardship, MCC expanded its welfare and healthcare initiatives.",
    image: "/leader-arumugasamy.jpg",
  },
  {
    id: 5,
    name: "Datuk Dr. D.M. Thuraiapah",
    title: "Fifth President",
    years: "1996 - 2003",
    duration: "7 years",
    description:
      "Datuk Dr. D.M. Thuraiapah led MCC through a transformative period marked by economic changes and evolving community needs. Under his stewardship, MCC strengthened its role in national dialogue, promoted national unity and racial harmony, and expanded welfare programs supporting thousands of families across Malaysia.",
    image: "/leader-thuraiapah.jpg",
  },
  {
    id: 6,
    name: "Dato' Dr NKS Tharmaseelan",
    title: "Sixth President",
    years: "2004 - Present",
    duration: "20+ years",
    description:
      "Dato' Dr NKS Tharmaseelan has provided visionary leadership for over two decades, guiding MCC into the modern era. His administration has focused on digital transformation, youth empowerment, women's advancement, and community resilience. Under his leadership, MCC continues to champion political representation, education advancement, and the preservation of cultural heritage.",
    image: "/leader-tharmaseelan.jpg",
  },
]

export default function PartyLeadersTimeline() {
  const [currentIndex, setCurrentIndex] = useState(0)

  const goToNext = () => {
    setCurrentIndex((prev) => (prev + 1) % partyLeaders.length)
  }

  const goToPrev = () => {
    setCurrentIndex((prev) => (prev - 1 + partyLeaders.length) % partyLeaders.length)
  }

  const currentLeader = partyLeaders[currentIndex]

  return (
    <section className="w-full py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-16 space-y-4 text-center">
          <div>
            <p className="text-[#003087] font-semibold text-sm uppercase tracking-wider mb-2">Our Leadership</p>
            <h2 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-4">History of Our Party Timeline</h2>
            <p className="text-gray-600 text-lg max-w-2xl mx-auto">
              A glorious journey of visionaries who shaped MCC - six decades of dedicated leadership and community
              service
            </p>
          </div>
        </div>

        {/* Timeline Card */}
        <div className="bg-gradient-to-br from-[#003087]/5 to-white rounded-2xl shadow-2xl overflow-hidden">
          <div className="grid md:grid-cols-2 gap-0">
            {/* Left Column - Image */}
            <div className="bg-gradient-to-br from-[#003087] to-[#001f52] flex items-center justify-center p-8 min-h-[500px]">
              <div className="relative w-full h-full flex items-center justify-center">
                <div className="relative w-80 h-96">
                  <Image
                    src={currentLeader.image || "/placeholder.svg"}
                    alt={currentLeader.name}
                    fill
                    className="object-cover rounded-lg shadow-2xl"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#003087]/80 via-transparent rounded-lg"></div>
                </div>
              </div>
            </div>

            {/* Right Column - Content */}
            <div className="p-8 sm:p-12 flex flex-col justify-between">
              {/* Content */}
              <div className="space-y-6">
                <div>
                  <p className="text-[#CE0000] font-bold text-sm uppercase tracking-wider mb-2">
                    President {currentIndex + 1}
                  </p>
                  <h3 className="text-3xl font-bold text-gray-900 mb-2">{currentLeader.name}</h3>
                  <p className="text-lg font-semibold text-[#003087]">{currentLeader.title}</p>
                </div>

                <div className="border-l-4 border-[#CE0000] pl-4 space-y-2">
                  <p className="text-gray-600 font-semibold">
                    <span className="text-[#003087] font-bold">Years of Service:</span> {currentLeader.years}
                  </p>
                  <p className="text-gray-600 font-semibold">
                    <span className="text-[#003087] font-bold">Duration:</span> {currentLeader.duration}
                  </p>
                </div>

                <p className="text-gray-700 leading-relaxed text-lg">{currentLeader.description}</p>
              </div>

              {/* Navigation */}
              <div className="mt-8 space-y-4">
                <div className="flex items-center gap-4">
                  <button
                    onClick={goToPrev}
                    className="flex items-center justify-center w-12 h-12 rounded-full bg-[#003087] text-white hover:bg-[#001f52] transition-colors shadow-lg"
                    aria-label="Previous president"
                  >
                    <ChevronLeft size={24} />
                  </button>
                  <div className="flex-1 h-2 bg-gray-200 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-[#003087] to-[#CE0000] transition-all duration-300"
                      style={{ width: `${((currentIndex + 1) / partyLeaders.length) * 100}%` }}
                    ></div>
                  </div>
                  <button
                    onClick={goToNext}
                    className="flex items-center justify-center w-12 h-12 rounded-full bg-[#CE0000] text-white hover:bg-[#b20000] transition-colors shadow-lg"
                    aria-label="Next president"
                  >
                    <ChevronRight size={24} />
                  </button>
                </div>
                <p className="text-center text-gray-600 font-semibold">
                  President {currentIndex + 1} of {partyLeaders.length}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Timeline Indicator Dots */}
        <div className="mt-8 flex justify-center gap-2">
          {partyLeaders.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentIndex(index)}
              className={`w-3 h-3 rounded-full transition-all ${
                index === currentIndex ? "bg-[#003087] w-8" : "bg-gray-300 hover:bg-gray-400"
              }`}
              aria-label={`Go to president ${index + 1}`}
            ></button>
          ))}
        </div>
      </div>
    </section>
  )
}
