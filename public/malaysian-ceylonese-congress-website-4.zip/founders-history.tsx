const founders = [
  {
    id: 1,
    name: "Mr. M.W. Navaratnam",
    title: "A.M.N. J.P",
    period: "1958 to 1969",
    description:
      "MCC was established as a political party with the aim of giving support to the then Alliance party. MCC has continuously supported the Barisan National. MCC was the brainchild of the late Mr M W Navaratnam and was formed to promote and preserve the Political, Educational, Economic, Social and Cultural aspects of the Malaysians of Ceylonese origin or Sri Lankan descent.",
    image: "/images/whatsapp-20image-202026-01-14-20at-2011.jpeg",
    role: "Founder & First President",
  },
  {
    id: 2,
    name: "Senator Tan Sri Dr. C. Sinnadurai",
    period: "1970 to 1983",
    description:
      "Leadership during expansion phase. Grew MCC's influence across Malaysia with strong parliamentary representation and expanded community programs.",
    image: "/images/whatsapp-20image-202026-01-14-20at-2011.jpeg",
    role: "Second President",
  },
  {
    id: 3,
    name: "Tan Sri Dato' Seri V. Jeyaratnam",
    period: "1983 to 1987",
    description:
      "Strengthened community initiatives and enhanced MCC's parliamentary presence. Focused on education and youth development.",
    image: "/images/whatsapp-20image-202026-01-14-20at-2011.jpeg",
    role: "Third President",
  },
  {
    id: 4,
    name: "Dato Dr N. Arumugasamy",
    title: "Neurosurgeon",
    period: "1988 to 1995",
    description:
      "Healthcare and education focus. Introduced landmark scholarship programs benefiting thousands of students. Enhanced medical and social welfare initiatives.",
    image: "/images/whatsapp-20image-202026-01-14-20at-2011.jpeg",
    role: "Fourth President",
  },
  {
    id: 5,
    name: "Datuk Dr. D.M. Thuraiapah",
    period: "1996 to 2003",
    description:
      "Economic and social advancement focus. Expanded MCC's reach to rural communities. Strengthened cultural preservation programs.",
    image: "/images/whatsapp-20image-202026-01-14-20at-2011.jpeg",
    role: "Fifth President",
  },
  {
    id: 6,
    name: "Dato' Dr NKS Tharmaseelan",
    period: "2004 to Present",
    description:
      "Current leadership modernizing MCC for the digital age while maintaining traditional values. Focus on youth empowerment and community welfare.",
    image: "/images/whatsapp-20image-202026-01-14-20at-2011.jpeg",
    role: "Sixth President",
  },
]
